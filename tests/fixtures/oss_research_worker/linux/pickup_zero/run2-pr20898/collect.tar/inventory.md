# Inventory

Cap per repository: 3
Collection status: failed

- eslint/eslint: matched 0, selected 0, excluded 0
